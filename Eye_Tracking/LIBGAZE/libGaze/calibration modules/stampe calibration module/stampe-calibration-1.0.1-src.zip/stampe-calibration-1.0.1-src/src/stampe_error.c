/****************************************************************************
* 	libGaze                                                       
*  	A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems   
*                                                               
*	Copyright(C) 2008 	
*	Max Planck Institute for Biological Cybernetics Tuebingen           
*	BWFIT     
*                                                             
*	All rights reserved.                                           
*                                                                   
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.                                                       
*                                                                           
****************************************************************************/
#include <stdio.h>
#include <stdarg.h>

#include "stampe_error.h"

FILE *cc_debug = NULL;
FILE *cc_error = NULL;

int aerror = 1;
int adebug = 0;

void _CALIBERROR_(const char *format, ...){
	cc_error = stderr;
	if(aerror){
		if (cc_error != NULL){
		
			va_list ap;
			fprintf(cc_error,"ERR Calibra:\t");
			
			va_start(ap,format);
			vfprintf(cc_error,format,ap);
			va_end(ap);
			fflush(cc_error);
		}
	}
}

void _CALIBDEBUG_(const char *format, ...){
	cc_debug = stdout;
	if(adebug){
		if(cc_debug != NULL){
			va_list ap;
			//printf("vd: %p\tstd: %p\n",vicon_debug,stdout);
			fprintf(cc_debug,"MSG Calibra:\t");
			va_start(ap,format);
			vfprintf(cc_debug,format,ap);		
			va_end(ap);
			fflush(cc_debug);
		}
	}
}
