/****************************************************************************
* 	libGaze
*  	A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems
*
*	Copyright(C) 2008
*	Max Planck Institute for Biological Cybernetics Tuebingen
*	BWFIT
*
*	All rights reserved.
*
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  Foobar is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
*
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_blas.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>

#include <tools/libGaze_vector_and_angles.h>

#include "stampe_calibration.h"
#include "stampe_types.h"
#include "stampe_error.h"

static t_stampe_calibration_data_set *sc_data = NULL;
static t_stampe_calibration_set* sc_set = NULL;
static gsl_vector* veye_left = NULL;
static gsl_vector* veye_right = NULL;


t_stampe_calibration_data* t_stampe_calibration_data_malloc(int n){
	t_stampe_calibration_data* cd = (t_stampe_calibration_data*)malloc(sizeof(t_stampe_calibration_data));

	cd->n = n;
	cd->alphas = (double*)malloc(n*sizeof(double));
	cd->betas = (double*)malloc(n*sizeof(double));

	cd->pupil_x = (double*)malloc(n*sizeof(double));
	cd->pupil_y = (double*)malloc(n*sizeof(double));
	return cd;

}

void t_stampe_calibration_data_free(t_stampe_calibration_data* ptr){
	if(ptr !=NULL){
		free(ptr->alphas);
		free(ptr->betas);
		free(ptr->pupil_x);
		free(ptr->pupil_y);

		free(ptr);
	}
}

t_stampe_calibration_data_set* t_stampe_calibration_data_set_malloc(int n){
	t_stampe_calibration_data_set *cds=(t_stampe_calibration_data_set*)malloc(sizeof(t_stampe_calibration_data_set));
	cds->n=n;
	cds->left_eye = t_stampe_calibration_data_malloc(n);
	cds->right_eye = t_stampe_calibration_data_malloc(n);
	return cds;
}

void t_stampe_calibration_data_set_free(t_stampe_calibration_data_set* ptr){
	if(ptr!=NULL){
		free(ptr->left_eye);
		free(ptr->right_eye);
		free(ptr);
	}
}


int calibration_init_module(int idebug, int ierror, FILE *fdebug, FILE *ferror){

	adebug=idebug;
	aerror=ierror;

	cc_debug = stdout;
	cc_error = stderr;

	veye_left = gsl_vector_calloc(3);
	veye_right = gsl_vector_calloc(3);

	sc_data = (t_stampe_calibration_data_set*)malloc(sizeof(t_stampe_calibration_data_set));

	_CALIBDEBUG_("init_module\n");
	return 0;

}

int calibration_fini_module(void)
{
	_CALIBDEBUG_("fini_module\n");

	//_CALIBDEBUG_("fclose cc_error\n");
 // fclose(cc_error);

	_CALIBDEBUG_("fini_module succesful\n");
	return 1;
}

int min(int a, int b){
	if (a>b){
		return b;
	}else {
		return a;
	}
}

int calculateGazeAnglesStampeWay(double pupil_x, double pupil_y,double *alpha, double *beta,t_stampe_calibration* sc){
	//_CALIBERROR_("calculateGazeAnglesStampeWay\n");
	double a1 = sc->a + (sc->b*pupil_x)+(sc->c*pupil_y)+(sc->d*pow(pupil_x,2))+(sc->e*pow(pupil_y,2));
	double b1 = sc->f + (sc->g*pupil_x)+(sc->h*pupil_y)+(sc->i*pow(pupil_x,2))+(sc->j*pow(pupil_y,2));

	if(a1!=0.0 || b1!=0.0){
		if(a1>=0.0 && b1>=0.0){
				*alpha = a1 + (sc->m[0]*a1*b1);
				*beta = b1 + (sc->n[0]*a1*b1);
		}else if(a1<=0.0 && b1>=0.0){
			*alpha = a1 + (sc->m[1]*a1*b1);
			*beta = b1 + (sc->n[1]*a1*b1);
		}else if(a1<=0.0 && b1<=0.0){
			*alpha = a1 + (sc->m[2]*a1*b1);
			*beta = b1 + (sc->n[2]*a1*b1);
		}else if(a1>=0.0 && b1<=0.0){
			*alpha = a1 + (sc->m[3]*a1*b1);
			*beta = b1 + (sc->n[3]*a1*b1);
		}
	}else{
		*alpha = a1;
		*beta = b1;
	}

	return 1;
}


int runStampeCalibration(t_stampe_calibration_data* scd, t_stampe_calibration* sc ){
	sc->is_calibrated = 1;
	//_CALIBERROR_("runStampeCalibration\n");
	//_CALIBERROR_("scd->n: %d\n",scd->n);
	t_stampe_calibration_data *cleaned_scd=t_stampe_calibration_data_malloc(scd->n);
	sc->calpha = scd->alphas[4];
	sc->cbeta = scd->betas[4];

	sc->cpupil_x = scd->pupil_x[4];
	sc->cpupil_y = scd->pupil_y[4];

	//_CALIBERROR_("preparing data\n");
	int i;
	for (i=0;i<scd->n;i++){
		cleaned_scd->alphas[i]=scd->alphas[i]-sc->calpha;
		cleaned_scd->betas[i]=scd->betas[i]-sc->cbeta;
		cleaned_scd->pupil_x[i]=scd->pupil_x[i]-sc->cpupil_x;
		cleaned_scd->pupil_y[i]=scd->pupil_y[i]-sc->cpupil_y;
	}
	//_CALIBERROR_("calculating a b c d e\n");
	//calculating a b c d e
	double m1[25];
	double a[5];
	// center fixation point
	int k=0;
	a[0]=cleaned_scd->alphas[4];
	m1[0+(5*k)]=1;
	m1[1+(5*k)]=cleaned_scd->pupil_x[4];
	m1[2+(5*k)]=cleaned_scd->pupil_y[4];
	m1[3+(5*k)]=pow(cleaned_scd->pupil_x[4],2);
	m1[4+(5*k)]=pow(cleaned_scd->pupil_y[4],2);

	// left fixation point
	k=1;
	a[1]=cleaned_scd->alphas[7];
	m1[0+(5*k)]=1;
	m1[1+(5*k)]=cleaned_scd->pupil_x[7];
	m1[2+(5*k)]=cleaned_scd->pupil_y[7];
	m1[3+(5*k)]=pow(cleaned_scd->pupil_x[7],2);
	m1[4+(5*k)]=pow(cleaned_scd->pupil_y[7],2);

	// right fixation point
	k=2;
	a[2]=cleaned_scd->alphas[1];
	m1[0+(5*k)]=1;
	m1[1+(5*k)]=cleaned_scd->pupil_x[1];
	m1[2+(5*k)]=cleaned_scd->pupil_y[1];
	m1[3+(5*k)]=pow(cleaned_scd->pupil_x[1],2);
	m1[4+(5*k)]=pow(cleaned_scd->pupil_y[1],2);

	// bottum	fixation point
	k=3;
	a[3]=cleaned_scd->alphas[3];
	m1[0+(5*k)]=1;
	m1[1+(5*k)]=cleaned_scd->pupil_x[3];
	m1[2+(5*k)]=cleaned_scd->pupil_y[3];
	m1[3+(5*k)]=pow(cleaned_scd->pupil_x[3],2);
	m1[4+(5*k)]=pow(cleaned_scd->pupil_y[3],2);

	// top fixation point
	k=4;
	a[4]=cleaned_scd->alphas[5];
	m1[0+(5*k)]=1;
	m1[1+(5*k)]=cleaned_scd->pupil_x[5];
	m1[2+(5*k)]=cleaned_scd->pupil_y[5];
	m1[3+(5*k)]=pow(cleaned_scd->pupil_x[5],2);
	m1[4+(5*k)]=pow(cleaned_scd->pupil_y[5],2);

	gsl_vector_view va=gsl_vector_view_array(a,5);
	gsl_vector* tmpa=gsl_vector_calloc(5);
	gsl_vector_memcpy(tmpa,&va.vector);

	gsl_matrix_view vm1 = gsl_matrix_view_array(m1,5,5);
	gsl_matrix* tmpm1 = gsl_matrix_calloc(5,5);
	gsl_matrix_memcpy(tmpm1,&vm1.matrix);

	gsl_vector* abcde = gsl_vector_calloc(5);
	//_CALIBERROR_("solving m1\n");
	int j;
	gsl_permutation *pv;
	pv = gsl_permutation_calloc(5);

	gsl_linalg_LU_decomp(tmpm1,pv,&j);
	gsl_linalg_LU_solve(tmpm1,pv,tmpa,abcde);

	sc->a = gsl_vector_get(abcde,0);
	sc->b = gsl_vector_get(abcde,1);
	sc->c = gsl_vector_get(abcde,2);
	sc->d = gsl_vector_get(abcde,3);
	sc->e = gsl_vector_get(abcde,4);
	sc->m[0] = 0.0;
	sc->m[1] = 0.0;
	sc->m[2] = 0.0;
	sc->m[3] = 0.0;


	//calculating f g h i j
	//_CALIBERROR_("calculating f g h i j\n");
	double m2[25];
	double b[5];
	// center fixation point
	k=0;
	b[0]=cleaned_scd->betas[4];
	m2[0+(5*k)]=1;
	m2[1+(5*k)]=cleaned_scd->pupil_x[4];
	m2[2+(5*k)]=cleaned_scd->pupil_y[4];
	m2[3+(5*k)]=pow(cleaned_scd->pupil_x[4],2);
	m2[4+(5*k)]=pow(cleaned_scd->pupil_y[4],2);

	// left fixation point
	k=1;
	b[1]=cleaned_scd->betas[7];
	m2[0+(5*k)]=1;
	m2[1+(5*k)]=cleaned_scd->pupil_x[7];
	m2[2+(5*k)]=cleaned_scd->pupil_y[7];
	m2[3+(5*k)]=pow(cleaned_scd->pupil_x[7],2);
	m2[4+(5*k)]=pow(cleaned_scd->pupil_y[7],2);

	// right fixation point
	k=2;
	b[2]=cleaned_scd->betas[1];
	m2[0+(5*k)]=1;
	m2[1+(5*k)]=cleaned_scd->pupil_x[1];
	m2[2+(5*k)]=cleaned_scd->pupil_y[1];
	m2[3+(5*k)]=pow(cleaned_scd->pupil_x[1],2);
	m2[4+(5*k)]=pow(cleaned_scd->pupil_y[1],2);

	// bottum	fixation point
	k=3;
	b[3]=cleaned_scd->betas[3];
	m2[0+(5*k)]=1;
	m2[1+(5*k)]=cleaned_scd->pupil_x[3];
	m2[2+(5*k)]=cleaned_scd->pupil_y[3];
	m2[3+(5*k)]=pow(cleaned_scd->pupil_x[3],2);
	m2[4+(5*k)]=pow(cleaned_scd->pupil_y[3],2);

	// top fixation point
	k=4;
	b[4]=cleaned_scd->betas[5];
	m2[0+(5*k)]=1;
	m2[1+(5*k)]=cleaned_scd->pupil_x[5];
	m2[2+(5*k)]=cleaned_scd->pupil_y[5];
	m2[3+(5*k)]=pow(cleaned_scd->pupil_x[5],2);
	m2[4+(5*k)]=pow(cleaned_scd->pupil_y[5],2);

	gsl_vector_view vb=gsl_vector_view_array(b,5);
	gsl_vector* tmpb=gsl_vector_calloc(5);
	gsl_vector_memcpy(tmpb,&vb.vector);

	gsl_matrix_view vm2 = gsl_matrix_view_array(m2,5,5);
	gsl_matrix* tmpm2 = gsl_matrix_calloc(5,5);
	gsl_matrix_memcpy(tmpm2,&vm2.matrix);

	gsl_vector* fghij = gsl_vector_calloc(5);
	//_CALIBERROR_("solving m2\n");
	int j2;
	gsl_permutation *pv2;
	pv2 = gsl_permutation_calloc(5);

	gsl_linalg_LU_decomp(tmpm2,pv2,&j2);
	gsl_linalg_LU_solve(tmpm2,pv2,tmpb,fghij);
	//_CALIBERROR_("soled\n");

	sc->f = gsl_vector_get(fghij,0);
	sc->g = gsl_vector_get(fghij,1);
	sc->h = gsl_vector_get(fghij,2);
	sc->i = gsl_vector_get(fghij,3);
	sc->j = gsl_vector_get(fghij,4);
	sc->n[0] = 0.0;
	sc->n[1] = 0.0;
	sc->n[2] = 0.0;
	sc->n[3] = 0.0;


	//_CALIBERROR_("calculating the correction quadrants\n");
	// calculating the correction quadrants
	double q1alpha;
	double q1beta;
	calculateGazeAnglesStampeWay(cleaned_scd->pupil_x[8],cleaned_scd->pupil_y[8],&q1alpha,&q1beta,sc);
	sc->m[0] = (cleaned_scd->alphas[8]-q1alpha)/(q1alpha*q1beta);
	sc->n[0] = (cleaned_scd->betas[8]-q1beta)/(q1alpha*q1beta);
	_CALIBDEBUG_("q1alpha: %f\tq1beta: %f\talpha: %f\tbeta: %f\n",q1alpha,q1beta,cleaned_scd->alphas[8],cleaned_scd->betas[8]);


	double q2alpha;
	double q2beta;
	calculateGazeAnglesStampeWay(cleaned_scd->pupil_x[2],cleaned_scd->pupil_y[2],&q2alpha,&q2beta,sc);
	sc->m[1] = (cleaned_scd->alphas[2]-q2alpha)/(q2alpha*q2beta);
	sc->n[1] = (cleaned_scd->betas[2]-q2beta)/(q2alpha*q2beta);
	_CALIBDEBUG_("q2alpha: %f\tq2beta: %f\talpha: %f\tbeta: %f\n",q2alpha,q2beta,cleaned_scd->alphas[2],cleaned_scd->betas[2]);


	double q3alpha;
	double q3beta;
	calculateGazeAnglesStampeWay(cleaned_scd->pupil_x[0],cleaned_scd->pupil_y[0],&q3alpha,&q3beta,sc);
	sc->m[2] = (cleaned_scd->alphas[0]-q3alpha)/(q3alpha*q3beta);
	sc->n[2] = (cleaned_scd->betas[0]-q3beta)/(q3alpha*q3beta);
	_CALIBDEBUG_("q3alpha: %f\tq3beta: %f\talpha: %f\tbeta: %f\n",q3alpha,q3beta,cleaned_scd->alphas[0],cleaned_scd->betas[0]);


	double q4alpha;
	double q4beta;
	calculateGazeAnglesStampeWay(cleaned_scd->pupil_x[6],cleaned_scd->pupil_y[6],&q4alpha,&q4beta,sc);
	sc->m[3] = (cleaned_scd->alphas[6]-q4alpha)/(q4alpha*q4beta);
	sc->n[3] = (cleaned_scd->betas[6]-q4beta)/(q4alpha*q4beta);
	//calculateGazeAnglesStampeWay(cleaned_scd->pupil_x[6],cleaned_scd->pupil_y[6],&q4alpha,&q4beta,sc);
	_CALIBDEBUG_("q4alpha: %f\tq4beta: %f\talpha: %f\tbeta: %f\n",q4alpha,q4beta,cleaned_scd->alphas[6],cleaned_scd->betas[6]);

	return 1;
}


int calibration_processCalibrationData(enum lg_eyes eye, t_calibration_data_set* cdataset){
	_CALIBDEBUG_("processCalibrationData\n");
	if(cdataset->num>0){
		sc_data =t_stampe_calibration_data_set_malloc(cdataset->num);
		//setting temporal pointer to the calibration data of the calibration data set
		t_calibration_data* cdata;
		cdata = cdataset->cdata;


		//_CALIBDEBUG_("%d\n",cdataset->num);

		int i;
		for(i=0;i<cdataset->num;i++){

			gsl_matrix_view hm_tmp = gsl_matrix_view_array(cdata[i].head.matrix,3,3);
			gsl_matrix *hm = gsl_matrix_calloc(3,3);
			gsl_matrix_memcpy(hm,&hm_tmp.matrix);
			gsl_vector_view hp = gsl_vector_view_array(cdata[i].head.position,3);

			/*
			if(cdata[i].dis_vec ==NULL){
				int xy[2];
				xy[0] = cdata[i].dis_x;
				xy[1] = cdata[i].dis_y;
 				cdata[i].dis_vec =(*(display->get3DPositionFromXY))(xy);
			}
	*/
			_CALIBDEBUG_("fov_alpha: %f\tfov_beta: %f\n",cdata[i].fov_alpha,cdata[i].fov_beta);
			_CALIBDEBUG_("ctarget_pos[%d]: %f\t%f\t%f\n",i,cdata[i].ctarget_pos[0],cdata[i].ctarget_pos[1],cdata[i].ctarget_pos[2]);
			gsl_vector_view dis_vec = gsl_vector_view_array(cdata[i].ctarget_pos,3);
			int j;
			gsl_permutation* p = gsl_permutation_calloc(3);
			gsl_linalg_LU_decomp(hm,p,&j);
			gsl_matrix* hm_inv = gsl_matrix_calloc(3,3);
			gsl_linalg_LU_invert(hm,p,hm_inv);

			//_CALIBERROR_("\nangles: %f\t%f\n",cdata[i].alpha,cdata[i].beta);

			if(eye == LG_EYE_BOTH || eye == LG_EYE_LEFT){
				sc_data->left_eye->pupil_x[i] = cdata[i].eye.pupil_x[0];
				sc_data->left_eye->pupil_y[i] = cdata[i].eye.pupil_y[0];

				//_CALIBDEBUG_("hpos[%d]=\n",i);
				//gsl_vector_f_CALIBERROR_(cc_debug,&hp.vector,"%g");
				gsl_vector* leye_pos;
				leye_pos = gsl_vector_calloc(3);
				//_CALIBDEBUG_("veye_left= %f\t%f\t%f\n",gsl_vector_get(veye_left,0),gsl_vector_get(veye_left,1),gsl_vector_get(veye_left,2));

				gsl_blas_dgemv(CblasNoTrans,1.0,hm,veye_left,1.0,leye_pos);
				//_CALIBDEBUG_("leye_pos= %f\t%f\t%f\n",gsl_vector_get(leye_pos,0),gsl_vector_get(leye_pos,1),gsl_vector_get(leye_pos,2));

				gsl_vector_add(leye_pos,&hp.vector);
				//_CALIBDEBUG_("leye_pos= %f\t%f\t%f\n",gsl_vector_get(leye_pos,0),gsl_vector_get(leye_pos,1),gsl_vector_get(leye_pos,2));

				gsl_vector* vl = gsl_vector_calloc(3);
				gsl_vector_memcpy(vl,&dis_vec.vector);
				//_CALIBDEBUG_("dis[%d]=\n",i);
				//gsl_vector_fprintf(cc_debug,&dis_vec.vector,"%g");
				//gsl_vector_fprintf(cc_debug,&dis_vec.vector,"%g");
				//_CALIBDEBUG_("leye_pos[%d]=\n",i);
				//gsl_vector_fprintf(cc_debug,leye_pos,"%g");
				//_CALIBDEBUG_("vl[%d]= %f\t%f\t%f\n",i,gsl_vector_get(vl,0),gsl_vector_get(vl,1),gsl_vector_get(vl,2));
				//_CALIBDEBUG_("leye_pos= %f\t%f\t%f\n",gsl_vector_get(leye_pos,0),gsl_vector_get(leye_pos,1),gsl_vector_get(leye_pos,2));
				gsl_vector_sub(vl,leye_pos);
				//_CALIBDEBUG_("vl[%d]= %f\t%f\t%f\n",i,gsl_vector_get(vl,0),gsl_vector_get(vl,1),gsl_vector_get(vl,2));

				//gsl_vector_fprintf(cc_debug,vl,"%g");
				//_CALIBDEBUG_("i: %d\tl= %f\tf=%f\n",i,l,faktor);
				//_CALIBDEBUG_("vl[%d]= %f\t%f\t%f\n",i,gsl_vector_get(vl,0),gsl_vector_get(vl,1),gsl_vector_get(vl,2));
				gsl_vector *vleft = gsl_vector_calloc(3);
				gsl_blas_dgemv(CblasNoTrans,1.0,hm_inv,vl,1.0,vleft);
				//_CALIBDEBUG_("\n");

				gsl_vector *test = lg_tools_get3DVectorFromAngles(lg_tools_radians(cdata[i].fov_alpha),lg_tools_radians(cdata[i].fov_beta));
				//_CALIBDEBUG_("test: %f\t%f\t%f\t%f\t%f\n",cdata[i].alpha,cdata[i].beta,test->data[0],test->data[1],test->data[2]);

				double *dtest = lg_tools_getYZAnglesFrom3DVector(test);
				_CALIBDEBUG_("test: %f\t%f\t%f\t%f\t%f\t%f\t%f\n",cdata[i].fov_alpha,cdata[i].fov_beta,dtest[0],dtest[1],test->data[0],test->data[1],test->data[2]);



				double *langles = lg_tools_getYZAnglesFrom3DVector(vleft);
				sc_data->left_eye->alphas[i] = langles[0];
				sc_data->left_eye->betas[i] = langles[1];
				_CALIBDEBUG_("langles: %f\t%f\t%f\t%f\t%f\n",langles[0],langles[1],vleft->data[0],vleft->data[1],vleft->data[2]);

			}

			if(eye == LG_EYE_BOTH || eye == LG_EYE_RIGHT){
				sc_data->right_eye->pupil_x[i] = cdata[i].eye.pupil_x[1];
				sc_data->right_eye->pupil_y[i] = cdata[i].eye.pupil_y[1];

				gsl_vector* reye_pos;
				reye_pos = gsl_vector_calloc(3);
				gsl_blas_dgemv(CblasNoTrans,1.0,hm,veye_right,1.0,reye_pos);
				gsl_vector_add(reye_pos,&hp.vector);
				gsl_vector* vr = gsl_vector_calloc(3);
				gsl_vector_memcpy(vr,&dis_vec.vector);
				gsl_vector_sub(vr,reye_pos);

				gsl_vector* vright = gsl_vector_calloc(3);
				gsl_blas_dgemv(CblasNoTrans,1.0,hm_inv,vr,1.0,vright);


				double *rangles = lg_tools_getYZAnglesFrom3DVector(vright);
				sc_data->right_eye->alphas[i] = rangles[0];
				sc_data->right_eye->betas[i] = rangles[1];
				//_CALIBERROR_("rangles: %f\t%f\n",rangles[0],rangles[1]);
			}
		}

		sc_set = (t_stampe_calibration_set*)malloc(sizeof(t_stampe_calibration_set));
		sc_set->left_eye.is_calibrated = 0;
		sc_set->right_eye.is_calibrated = 0;
		if(eye == LG_EYE_BOTH || eye == LG_EYE_LEFT){

			runStampeCalibration(sc_data->left_eye,&(sc_set->left_eye));

		}

		if(eye == LG_EYE_BOTH || eye == LG_EYE_RIGHT){
			runStampeCalibration(sc_data->right_eye,&(sc_set->right_eye));
		}

//		for(i=0;i<cdataset->num;i++){
			//_CALIBDEBUG_("processCalibrationData: dis_x= %d\tdis_y= %d\n",cdata[i].dis_x,cdata[i].dis_y);
			//_CALIBDEBUG_("alpha: %f\tbeta: %f\n",cdata[i].alpha,cdata[i].beta);
			//_CALIBDEBUG_("CalibDisplayPos: %f\t%f\t%f\n",cdata[i].dis_vec[0],cdata[i].dis_vec[1],cdata[i].dis_vec[2]);

//			t_data gd;
			//gd.gaze = (t_gaze_data*)malloc(2*sizeof(t_gaze_data));
//			calibration_procesEyeAndHeadData(display,&cdata[i].eye,&cdata[i].head,&gd);
			//_CALIBDEBUG_("xy_left: dis_x= %d\tdis_y= %d\n",gd.dis_x[0],gd.dis_y[0]);
			//_CALIBDEBUG_("xy_right: dis_x= %d\tdis_y= %d\n",gd.dis_x[1],gd.dis_y[1]);

//		}

	}else{
		return -1;
	}


	return 0;
}
/*
int calibration_procesEyeAndHeadData( t_raw_eye_data* edata, t_raw_head_data* hdata, t_data* gaze){

	//_CALIBDEBUG_("procesEyeAndHeadData:\n");
	//_CALIBDEBUG_("eye: %f\t%f\t%f\t%f\n",edata->pupil_x[0],edata->pupil_y[0],edata->pupil_x[1],edata->pupil_y[1]);
	//_CALIBDEBUG_("head: %f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t\n",hdata->position[0],hdata->position[1],hdata->position[2],hdata->matrix[0],hdata->matrix[1],hdata->matrix[2],hdata->matrix[3],hdata->matrix[4],hdata->matrix[5],hdata->matrix[6],hdata->matrix[7],hdata->matrix[8]);
	if (sc_set->left_eye.is_calibrated == 1 && (edata->eye_available ==LG_EYE_BOTH || edata->eye_available == LG_EYE_LEFT)){

		double alpha;
		double beta;

		calculateGazeAnglesStampeWay(edata->pupil_x[0]-sc_set->left_eye.cpupil_x,edata->pupil_y[0]-sc_set->left_eye.cpupil_y,&alpha,&beta,&sc_set->left_eye);

		alpha += sc_set->left_eye.calpha;
		beta += sc_set->left_eye.cbeta;
		//_CALIBDEBUG_("lalpha: %f\tlbeta: %f\n",alpha,beta);
		gsl_vector* di = lg_tools_get3DVectorFromAngles(lg_tools_radians(alpha),lg_tools_radians(beta));

		double *rangles;
		rangles = lg_tools_getYZAnglesFrom3DVector(di);
		//_CALIBDEBUG_("procesEyeAndHeadData: test0\n");
		gsl_vector* rdi = NULL;
		rdi = gsl_vector_calloc(3);
		gsl_matrix_view hm_tmp =gsl_matrix_view_array(hdata->matrix,3,3);
		gsl_matrix *hm = gsl_matrix_calloc(3,3);
		gsl_matrix_memcpy(hm,&hm_tmp.matrix);
		gsl_blas_dgemv(CblasNoTrans,1.0,hm,di,1.0,rdi);
		//_CALIBDEBUG_("procesEyeAndHeadData: test1\n");

		gsl_vector *eyepos =gsl_vector_calloc(3);
		gsl_blas_dgemv(CblasNoTrans,1.0,hm,veye_left,1.0,eyepos);
		gsl_vector_view hp = gsl_vector_view_array(hdata->position,3);
		gsl_vector_add(eyepos,&hp.vector);

		//_CALIBDEBUG_("procesEyeAndHeadData: test2\n");

		memcpy(gaze->gaze[0].origin,eyepos->data,3*sizeof(double));
		memcpy(gaze->gaze[0].direction,rdi->data,3*sizeof(double));
		double *gangles = lg_tools_getYZAnglesFrom3DVector(rdi);
		gaze->gaze[0].dangles[0] = gangles[0];
		gaze->gaze[0].dangles[1] = gangles[1];


		double * p = NULL;
		_CALIBDEBUG_("d_getIntersectionWithScreen: %f\t%f\t%f\t\t%f\t%f\t%f\n",eyepos->data[0],eyepos->data[1],eyepos->data[2],rdi->data[0],rdi->data[1],rdi->data[2]);
		//p= d_getIntersectionWithScreen(display,eyepos->data,rdi->data);
		//p= (*(display->getIntersectionWithScreen))(eyepos->data,rdi->data);
		//int *xy = NULL;
		//xy = d_getXYPositionFrom3D(display,p);
		//_CALIBDEBUG_("LeftDisplayPos: %f\t%f\t%f\n",p[0],p[1],p[2]);
		//xy = (*(display->getXYPositionFrom3D))(p);
		//gaze->dis_x[0]= xy[0];
		//gaze->dis_y[0]= xy[1];
		gaze->alpha[0] = rangles[0];
		gaze->beta[0] = rangles[1];

	}else{
		//_CALIBERROR_("procesEyeAndHeadData: could not process left eye data\n");
		//_CALIBERROR_("procesEyeAndHeadData: data of left eye is not available or system is not calibrated\n");
	}
	if (sc_set->right_eye.is_calibrated == 1 && (edata->eye_available ==LG_EYE_BOTH || edata->eye_available == LG_EYE_RIGHT)){

			double alpha;
			double beta;

			calculateGazeAnglesStampeWay(edata->pupil_x[1]-sc_set->right_eye.cpupil_x,edata->pupil_y[1]-sc_set->right_eye.cpupil_y,&alpha,&beta,&sc_set->right_eye);

			alpha += sc_set->right_eye.calpha;
			beta += sc_set->right_eye.cbeta;
			//_CALIBDEBUG_("ralpha: %f\trbeta: %f\n",alpha,beta);
			gsl_vector* di = lg_tools_get3DVectorFromAngles(lg_tools_radians(alpha),lg_tools_radians(beta));

			double *rangles;
			rangles = lg_tools_getYZAnglesFrom3DVector(di);
			//_CALIBDEBUG_("procesEyeAndHeadData: test0\n");
			gsl_vector* rdi = NULL;
			rdi = gsl_vector_calloc(3);
			gsl_matrix_view hm_tmp =gsl_matrix_view_array(hdata->matrix,3,3);
			gsl_matrix *hm = gsl_matrix_calloc(3,3);
			gsl_matrix_memcpy(hm,&hm_tmp.matrix);
			gsl_blas_dgemv(CblasNoTrans,1.0,hm,di,1.0,rdi);
			//_CALIBDEBUG_("procesEyeAndHeadData: test1\n");

			gsl_vector *eyepos =gsl_vector_calloc(3);
			gsl_blas_dgemv(CblasNoTrans,1.0,hm,veye_right,1.0,eyepos);
			gsl_vector_view hp = gsl_vector_view_array(hdata->position,3);
			gsl_vector_add(eyepos,&hp.vector);

			memcpy(gaze->gaze[1].origin,eyepos->data,3*sizeof(double));
			memcpy(gaze->gaze[1].direction,rdi->data,3*sizeof(double));

			double *gangles = lg_tools_getYZAnglesFrom3DVector(rdi);
			gaze->gaze[1].dangles[0] = gangles[0];
			gaze->gaze[1].dangles[1] = gangles[1];

			double * p = NULL;
			//p= d_getIntersectionWithScreen(display,eyepos->data,rdi->data);
			//p= (*(display->getIntersectionWithScreen))(eyepos->data,rdi->data);
			//int *xy = NULL;
			//xy = d_getXYPositionFrom3D(display,p);
			//_CALIBDEBUG_("LeftDisplayPos: %f\t%f\t%f\n",p[0],p[1],p[2]);
			//xy = (*(display->getXYPositionFrom3D))(p);
			//gaze->dis_x[1]= xy[0];
			//gaze->dis_y[1]= xy[1];
			gaze->alpha[1] = rangles[0];
			gaze->beta[1] = rangles[1];

		}else{
			//_CALIBERROR_("procesEyeAndHeadData: could not process right eye data\n");
			//_CALIBERROR_("procesEyeAndHeadData: data of right eye is not available or system is not calibrated\n");
		}

	return 0;
}
*/

int calibration_processEyeData( t_raw_eye_data* redata, t_eye_data* edata){
	_CALIBDEBUG_("calibration_procesEyeData: %f\t%f\t%f\t%f\n",redata->pupil_x[0],redata->pupil_y[0],redata->pupil_x[1],redata->pupil_y[1]);
	edata->eye_available = redata->eye_available;
	if (sc_set->left_eye.is_calibrated == 1 && (redata->eye_available ==LG_EYE_BOTH || redata->eye_available == LG_EYE_LEFT)){
		//_CALIBDEBUG_("left\n");
		double alpha;
		double beta;

		calculateGazeAnglesStampeWay(redata->pupil_x[0]-sc_set->left_eye.cpupil_x,redata->pupil_y[0]-sc_set->left_eye.cpupil_y,&alpha,&beta,&sc_set->left_eye);

		alpha += sc_set->left_eye.calpha;
		beta += sc_set->left_eye.cbeta;
		_CALIBDEBUG_("lalpha: %f\tlbeta: %f\n",alpha,beta);
		//gsl_vector* di = get3DVectorFromAngles(radians(alpha),radians(beta));

		//edata->viewing_direction[0][0] = gsl_vector_get(di,0);
		//edata->viewing_direction[0][1] = gsl_vector_get(di,1);
		//edata->viewing_direction[0][2] = gsl_vector_get(di,2);

		edata->alpha[0] = alpha;
		edata->beta[0] = beta;

		//gsl_vector_free(di);

	}else{
		//_CALIBERROR_("procesEyeAndHeadData: could not process left eye data\n");
		//_CALIBERROR_("procesEyeAndHeadData: data of left eye is not available or system is not calibrated\n");
	}
	if (sc_set->right_eye.is_calibrated == 1 && (edata->eye_available ==LG_EYE_BOTH || edata->eye_available == LG_EYE_RIGHT)){
			//_CALIBDEBUG_("right\n");
			double alpha;
			double beta;

			calculateGazeAnglesStampeWay(redata->pupil_x[1]-sc_set->right_eye.cpupil_x,redata->pupil_y[1]-sc_set->right_eye.cpupil_y,&alpha,&beta,&sc_set->right_eye);

			alpha += sc_set->right_eye.calpha;
			beta += sc_set->right_eye.cbeta;
			_CALIBDEBUG_("ralpha: %f\trbeta: %f\n",alpha,beta);
			//gsl_vector* di = get3DVectorFromAngles(radians(alpha),radians(beta));

			//edata->viewing_direction[1][0] = gsl_vector_get(di,0);
			//edata->viewing_direction[1][1] = gsl_vector_get(di,1);
			//edata->viewing_direction[1][2] = gsl_vector_get(di,2);

			edata->alpha[1] = alpha;
			edata->beta[1] = beta;

			//gsl_vector_free(di);
		}else{
			//_CALIBERROR_("procesEyeAndHeadData: could not process right eye data\n");
			//_CALIBERROR_("procesEyeAndHeadData: data of right eye is not available or system is not calibrated\n");
		}

	return 0;
}
