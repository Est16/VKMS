/****************************************************************************
* 	libGaze                                                       
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems   
*                                                               
*	Copyright(C) 2008 	
*	Max Planck Institute for Biological Cybernetics Tuebingen           
*	BWFIT     
*                                                             
*	All rights reserved.                                           
*                                                                   
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.                                                       
*                                                                           
****************************************************************************/
#ifndef STAMPE_TYPES_H_
#define STAMPE_TYPES_H_

typedef struct{
	int n;
	double *pupil_x;
	double *pupil_y;
	double *alphas;
	double *betas;
}t_stampe_calibration_data;

typedef struct{
	int n;
	int eyes;
	t_stampe_calibration_data *left_eye;
	t_stampe_calibration_data *right_eye;
}t_stampe_calibration_data_set;

typedef struct{
	
	int is_calibrated;
	
	double calpha;
	double cbeta;
	
	double cpupil_x;
	double cpupil_y;
	
	double a;
	double b;
	double c;
	double d;
	double e;
	
	double f;
	double g;
	double h;
	double i;
	double j;
	
	double m[4];
	double n[4];

}t_stampe_calibration;

typedef struct{
	t_stampe_calibration left_eye;
	t_stampe_calibration right_eye;
	
}t_stampe_calibration_set;

t_stampe_calibration_data* t_stampe_calibration_data_malloc(int n);

void  t_stampe_calibration_data_free(t_stampe_calibration_data* ptr);

t_stampe_calibration_data_set* t_stampe_calibration_data_set_malloc(int n);

void  t_stampe_calibration_data_set_free(t_stampe_calibration_data_set* ptr);
#endif /*STAMPE_TYPES_H_*/
