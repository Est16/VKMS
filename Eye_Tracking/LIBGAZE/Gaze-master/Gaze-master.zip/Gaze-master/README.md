Gaze-Browser
====

this repository contains the sourcecode for the bachelor thesis 2012/2013 Gaze-Browser at the berne university of applied sciences

checkout http://gaze.frickler.ch/ to get an overview of our thesis. 

Directory-Structure:
 - doc/         > contains the Bachelor Thesis documentation
 - doc/cpp/     > contains the Doxygen C++ API documentation 
 - GazeLib/     > contains the source code of the gaze tracking library
 - GazeBrowser/ > contains the source code of our gaze controlled webbrowser

(C) 2013 Feuz, Rindisbacher
