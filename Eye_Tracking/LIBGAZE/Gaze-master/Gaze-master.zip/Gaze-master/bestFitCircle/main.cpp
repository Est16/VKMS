#include <cstdlib>

using namespace std;

/*
 * you don't need this. run the BestFitCircleTest in Netbeans!
 */
int main(int argc, char** argv) {

    // DO NOTHING
    return 0;
}

