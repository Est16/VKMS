this projects is a static library with all our algorithms and contants. 

usage:
 - create a new eclipse project
 - configure an include path pointing to the GazeLib Project
 - configure a library include path pointing to the GazeLib/Debug directory
 - add the GazeLib Library to your project settings
 - Under Project Properties of your project add GazeLib to the "Project References"
 - Compile your project
 
The GazeLib Project does not need the opencv includes or libraries. make sure that you include them in your own eclipse project.