Face-detection-using-opencv-in-visual-studio-2010
==================================================

This is solution contain source code for face detection as well as eye detection in opencv.
I made this as simple as possible. If you face any issue related to this project feel free to comment.


Thank You.
