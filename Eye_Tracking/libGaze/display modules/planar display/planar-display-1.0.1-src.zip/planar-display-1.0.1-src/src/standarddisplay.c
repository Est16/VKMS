/****************************************************************************
* 	libGaze
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems
*
*	Copyright(C) 2008
*	Max Planck Institute for Biological Cybernetics Tuebingen
*	BWFIT
*
*	All rights reserved.
*
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.
*
****************************************************************************/
#include <stdlib.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>

#include "standarddisplay.h"
#include "standarddisplay_types.h"
#include "standarddisplay_config.h"

STANDARDDISPLAY *standard_display = NULL;

int display_init_module(int idebug, int ierror, FILE *fdebug, FILE *ferror){
	displaydebug=idebug;
	displayerror=ierror;

	display_debug = stdout;
	display_error = stderr;
	return 1;
}

int display_fini_module(void){
		free(standard_display);
	return 1;
}

int display_configure(char* filename,int *width, int *height){
	_DISPLAYDEBUG_("Display: configure\n");

	if(standard_display != NULL){
		free(standard_display);
	}

	standard_display = (STANDARDDISPLAY*)malloc(sizeof(STANDARDDISPLAY));

  //Read config file and initialize config structure
	_DISPLAYDEBUG_("parse_config_file\n");
	if (!parse_config_file(filename,standard_display))
  {
		_DISPLAYERROR_("Could not parse config file\n");
    return -1;
  }

	gsl_vector *d;
	gsl_vector *dx;
	gsl_vector *dy;

	d = gsl_vector_calloc(3);
	d->data[0] = standard_display->d0[0];
	d->data[1] = standard_display->d0[1];
	d->data[2] = standard_display->d0[2];
	standard_display->d = (void*)d;

	dx = gsl_vector_calloc(3);
	dx->data[0] = standard_display->d1[0]-standard_display->d0[0];
	dx->data[1] = standard_display->d1[1]-standard_display->d0[1];
	dx->data[2] = standard_display->d1[2]-standard_display->d0[2];
	standard_display->dx = (void*)dx;



	dy = gsl_vector_calloc(3);
	dy->data[0] = standard_display->d3[0]-standard_display->d0[0];
	dy->data[1] = standard_display->d3[1]-standard_display->d0[1];
	dy->data[2] = standard_display->d3[2]-standard_display->d0[2];
	standard_display->dy = (void*)dy;

	*width = standard_display->res_width;
	*height = standard_display->res_height;

	return 0;
}

double* display_get3DPositionFromXY(int* xy){
	double *pos;
	pos = (double*)malloc(3*sizeof(double));

	double a;
	double b;
	//a= ((double)xy[0])/((double)dis->res_width);
	//b= ((double)xy[1])/((double)dis->res_height);
	a= ((double)xy[0]-standard_display->offsets[0])/((double)standard_display->res_width-(standard_display->offsets[0]+standard_display->offsets[2]));
	b= ((double)xy[1]-standard_display->offsets[1])/((double)standard_display->res_height-(standard_display->offsets[1]+standard_display->offsets[3]));
	/*
	gsl_vector* p;
	p = gsl_vector_alloc(3);
	gsl_vector_set_zero(p);
	gsl_vector_add(p,(gsl_vector*)standard_display->d);
	*/
	pos[0]=((gsl_vector*)standard_display->d)->data[0]+(((gsl_vector*)standard_display->dx)->data[0]*a)+(((gsl_vector*)standard_display->dy)->data[0]*b);
	pos[1]=((gsl_vector*)standard_display->d)->data[1]+(((gsl_vector*)standard_display->dx)->data[1]*a)+(((gsl_vector*)standard_display->dy)->data[1]*b);
	pos[2]=((gsl_vector*)standard_display->d)->data[2]+(((gsl_vector*)standard_display->dx)->data[2]*a)+(((gsl_vector*)standard_display->dy)->data[2]*b);
	return pos;
}

int* display_getXYPositionFrom3D(double* pos){
	int *xy;
	xy = (int*)malloc(2*sizeof(int));

	gsl_matrix *mat;

	mat = gsl_matrix_calloc(3,2);
	gsl_matrix_set(mat,0,0,((gsl_vector*)standard_display->dx)->data[0]);
	gsl_matrix_set(mat,1,0,((gsl_vector*)standard_display->dx)->data[1]);
	gsl_matrix_set(mat,2,0,((gsl_vector*)standard_display->dx)->data[2]);
	gsl_matrix_set(mat,0,1,((gsl_vector*)standard_display->dy)->data[0]);
	gsl_matrix_set(mat,1,1,((gsl_vector*)standard_display->dy)->data[1]);
	gsl_matrix_set(mat,2,1,((gsl_vector*)standard_display->dy)->data[2]);

	gsl_vector *a;
	a = gsl_vector_calloc(3);

	a->data[0] = pos[0]-((gsl_vector*)standard_display->d)->data[0];
	a->data[1] = pos[1]-((gsl_vector*)standard_display->d)->data[1];
	a->data[2] = pos[2]-((gsl_vector*)standard_display->d)->data[2];
	//_DEBUG_("pos: %f\t%f\td: %f\t%f\n",pos[0],pos[1],((gsl_vector*)standard_display->d)->data[0],((gsl_vector*)standard_display->d)->data[1]);
	//_DEBUG_("mat: %f\t%f\t\%f\t%f\n",gsl_matrix_get(mat,0,0),gsl_matrix_get(mat,0,1),gsl_matrix_get(mat,1,0),gsl_matrix_get(mat,1,1));
	//_DEBUG_("vec: %f\t%f\n",a->data[0],a->data[1]);
	gsl_vector *x;
	gsl_vector* tau;
	gsl_vector* residual;

	x = gsl_vector_calloc(2);
	tau = gsl_vector_calloc(2);
	residual = gsl_vector_calloc(3);

	gsl_linalg_QR_decomp(mat,tau);
	gsl_linalg_QR_lssolve(mat,tau,a,x,residual);

	/*
	int i;
	gsl_permutation *pv;
	pv = gsl_permutation_calloc(2);

	gsl_linalg_LU_decomp(mat,pv,&i);
	gsl_linalg_LU_solve(mat,pv,a,x);
	*/
	//xy[0]=(int)(x->data[0] * (double)standard_display->res_width);
	//xy[1]=(int)(x->data[1] * (double)standard_display->res_height);
	// _DEBUG_("x: %d\ty:%d\n",xy[0],xy[1]);
	xy[0]=(int)(standard_display->offsets[0] + (x->data[0] * ((double)standard_display->res_width - (standard_display->offsets[0]+standard_display->offsets[2]))));
	xy[1]=(int)(standard_display->offsets[1] + (x->data[1] * ((double)standard_display->res_height - (standard_display->offsets[1]+standard_display->offsets[3]))));

	//xy[1]=(int)(x->data[1] * (double)standard_display->res_height);
	//printf("STANDARDDISPLAY: getXYPositionFrom3D: x %d\ty %d\n",xy[0],xy[1]);

	gsl_vector_free(a);
	gsl_vector_free(x);
	gsl_vector_free(tau);
	gsl_vector_free(residual);
	gsl_matrix_free(mat);
	//gsl_permutation_free(pv);
	return xy;
}

/*
 * int* display_getXYFromPositionAndDirection(double* pos ,double* direction){
	int *xy;

	xy = (int*)malloc(2*sizeof(int));


	gsl_vector *b;
	b = gsl_vector_calloc(3);
	b->data[0] = -direction[0];
	b->data[1] = -direction[1];
	b->data[2] = -direction[2];

	gsl_vector *a;
	a = gsl_vector_calloc(3);
	a->data[0] = pos[0]-((gsl_vector*)standard_display->d)->data[0];
	a->data[1] = pos[1]-((gsl_vector*)standard_display->d)->data[1];
	a->data[2] = pos[2]-((gsl_vector*)standard_display->d)->data[2];

	gsl_matrix *mat;
	mat = gsl_matrix_calloc(3,3);

	gsl_matrix_set_col(mat,0,(gsl_vector*)standard_display->dx);
	gsl_matrix_set_col(mat,1,(gsl_vector*)standard_display->dy);
	gsl_matrix_set_col(mat,2,b);

	gsl_vector *x;
	x = gsl_vector_calloc(3);
	int i;
	gsl_permutation *pv;
	pv = gsl_permutation_calloc(3);
	gsl_linalg_LU_decomp(mat,pv,&i);
	gsl_linalg_LU_solve(mat,pv,a,x);

	//xy[0]=(int)(x->data[0] * (double)standard_display->res_width);
	//xy[1]=(int)(x->data[1] * (double)standard_display->res_height);
	xy[0]=(int)(standard_display->offsets[0] + (x->data[0] * ((double)standard_display->res_width - (standard_display->offsets[0]+standard_display->offsets[2]))));
	xy[1]=(int)(standard_display->offsets[1] + (x->data[1] * ((double)standard_display->res_height - (standard_display->offsets[1]+standard_display->offsets[3]))));
	gsl_vector_free(a);
	gsl_vector_free(b);
	gsl_vector_free(x);
	gsl_matrix_free(mat);
	gsl_permutation_free(pv);
	return xy;
}
*/
double* display_getIntersectionWithScreen(double* pos ,double* direction){
	//printf("test\n");
	gsl_vector *b = NULL;

	b = gsl_vector_calloc(3);

	b->data[0] = -direction[0];
	b->data[1] = -direction[1];
	b->data[2] = -direction[2];
  
	gsl_vector *a;
	a = gsl_vector_calloc(3);
	a->data[0] = pos[0]-((gsl_vector*)standard_display->d)->data[0];
	a->data[1] = pos[1]-((gsl_vector*)standard_display->d)->data[1];
	a->data[2] = pos[2]-((gsl_vector*)standard_display->d)->data[2];

	gsl_matrix *mat;
	mat = gsl_matrix_calloc(3,3);

	gsl_matrix_set_col(mat,0,(gsl_vector*)standard_display->dx);
	gsl_matrix_set_col(mat,1,(gsl_vector*)standard_display->dy);
	gsl_matrix_set_col(mat,2,b);

	gsl_vector *x;
	x = gsl_vector_calloc(3);
	int i;
	gsl_permutation *pv;
	pv = gsl_permutation_calloc(3);
	gsl_linalg_LU_decomp(mat,pv,&i);
	gsl_linalg_LU_solve(mat,pv,a,x);

	double *ipoint = NULL;
	ipoint = (double*)malloc(3*sizeof(double));

	ipoint[0]=((gsl_vector*)standard_display->d)->data[0]+(((gsl_vector*)standard_display->dx)->data[0]*x->data[0])+(((gsl_vector*)standard_display->dy)->data[0]*x->data[1]);
	ipoint[1]=((gsl_vector*)standard_display->d)->data[1]+(((gsl_vector*)standard_display->dx)->data[1]*x->data[0])+(((gsl_vector*)standard_display->dy)->data[1]*x->data[1]);
	ipoint[2]=((gsl_vector*)standard_display->d)->data[2]+(((gsl_vector*)standard_display->dx)->data[2]*x->data[0])+(((gsl_vector*)standard_display->dy)->data[2]*x->data[1]);

	//printf("a: %f\tb:%f\tc: %f\n",x->data[0],x->data[1],x->data[2]);

	gsl_vector_free(a);
	gsl_vector_free(b);
	gsl_vector_free(x);
	gsl_matrix_free(mat);
	gsl_permutation_free(pv);

  //_DISPLAYDEBUG_("getIntersectionWithScreen: SUCCESS\n");

	return ipoint;
}

