#include <stdio.h>
#include <stdarg.h>
#include "standarddisplay_error.h"

FILE *display_debug = NULL;
FILE *display_error = NULL;

int displayerror = 0;
int displaydebug = 0;

void _DISPLAYERROR_(const char *format, ...){

	if(displayerror>0){
		if (display_error != NULL){

			va_list ap;
			fprintf(display_error,"ERR Display:\t");

			va_start(ap,format);
			vfprintf(display_error,format,ap);
			va_end(ap);
			fflush(display_error);
		}
	}
}

void _DISPLAYDEBUG_(const char *format, ...){
	if(displaydebug>0){
		if(display_debug != NULL){
			va_list ap;
			//printf("vd: %p\tstd: %p\n",fastrak_debug,stdout);
			fprintf(display_debug,"MSG Display:\t");
			va_start(ap,format);
			vfprintf(display_debug,format,ap);
			va_end(ap);
			fflush(display_debug);
		}
	}
}


