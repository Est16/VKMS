#ifndef STANDARDDISPLAY_CONFIG_H_
#define STANDARDDISPLAY_CONFIG_H_

#include "standarddisplay_types.h"

int parse_config_file(char *filename, t_standard_display* configuration);

#endif /*STANDARDDISPLAY_CONFIG_H_*/

