/****************************************************************************
* 	libGaze                                                       
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems   
*                                                               
*	Copyright(C) 2008 	
*	Max Planck Institute for Biological Cybernetics Tuebingen           
*	BWFIT     
*                                                             
*	All rights reserved.                                           
*                                                                   
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.                                                       
*                                                                           
****************************************************************************/
#ifndef STANDARDDISPLAY_TYPES_H_
#define STANDARDDISPLAY_TYPES_H_

/*
 * 
 * 
 */
typedef struct{
	int res_width;
	int res_height;
	
	/*Display position*/
	double d0[3];	//upper-left
	double d1[3];	//upper-right
	double d2[3];	//bottom-right
	double d3[3];	//bottom-left
	int offsets[4]; //the pixel offests of each side
	
	void *d;
	void *dx;
	void *dy;
}t_standard_display;

typedef t_standard_display STANDARDDISPLAY;


#endif /*STANDARDDISPLAY_TYPES_H_*/
