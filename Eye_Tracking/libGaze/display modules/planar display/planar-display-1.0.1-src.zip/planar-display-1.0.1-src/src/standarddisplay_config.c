#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <parse_conf.h>
//#include <libconfig.h>

#include "standarddisplay_error.h"
#include "standarddisplay_config.h"

/**
 * This function is used to parse the given
 * configuration file into the t_standard_display
 * structure that is used to control
 * the behaviour of this module.
 * It uses the parse_conf dll Version 1.0 which expects a special
 * configuration file structure, like
 * #Comments
 * [FIRSTSECTION]
 *   stringparameter = "value"
 *   # comment
 *   intparameter = 10
 * [SECONDSECTION]
 *   parameter = 4
 *
 * Don´t add a semicolon behind each line,
 * and don´t forget a linefeed at the end of file.
 * 
 * Returns: True if parsing was successful.
 */
int parse_config_file(char *filename, t_standard_display* cfg)
{
	_DISPLAYDEBUG_("parse_config_file\n");

  //Allocate memory for new configuration structure.
	t_standard_display* configuration = (t_standard_display*)malloc(sizeof(t_standard_display));

	pcnf_t *pcnf = pcnf_alloc();
	pcnf_read(pcnf,filename);

	configuration->res_width=pcnf_iget_dv(pcnf,"SIZE","width",1024);
	configuration->res_height=pcnf_iget_dv(pcnf,"SIZE","height",768);

  configuration->d0[0] = pcnf_fget_dv(pcnf,"CORNERS", "topleftX",0.0f);
  configuration->d0[1] = pcnf_fget_dv(pcnf,"CORNERS", "topleftY",0.0f);
  configuration->d0[2] = pcnf_fget_dv(pcnf,"CORNERS", "topleftZ",0.0f);
  configuration->d1[0] = pcnf_fget_dv(pcnf,"CORNERS", "toprightX",0.0f);
  configuration->d1[1] = pcnf_fget_dv(pcnf,"CORNERS", "toprightY",0.0f);
  configuration->d1[2] = pcnf_fget_dv(pcnf,"CORNERS", "toprightZ",0.0f);
  configuration->d2[0] = pcnf_fget_dv(pcnf,"CORNERS", "bottomrightX",0.0f);
  configuration->d2[1] = pcnf_fget_dv(pcnf,"CORNERS", "bottomrightY",0.0f);
  configuration->d2[2] = pcnf_fget_dv(pcnf,"CORNERS", "bottomrightZ",0.0f);
  configuration->d3[0] = pcnf_fget_dv(pcnf,"CORNERS", "bottomleftX",0.0f);
  configuration->d3[1] = pcnf_fget_dv(pcnf,"CORNERS", "bottomleftY",0.0f);
  configuration->d3[2] = pcnf_fget_dv(pcnf,"CORNERS", "bottomleftZ",0.0f);

  configuration->offsets[0]=pcnf_fget_dv(pcnf,"OFFSET", "offset0",0.0f);
  configuration->offsets[1]=pcnf_fget_dv(pcnf,"OFFSET", "offset1",0.0f);
  configuration->offsets[2]=pcnf_fget_dv(pcnf,"OFFSET", "offset2",0.0f);
  configuration->offsets[3]=pcnf_fget_dv(pcnf,"OFFSET", "offset3",0.0f);

  memcpy(cfg,configuration,sizeof(t_standard_display));
	pcnf_free(pcnf);

	_DISPLAYDEBUG_("parse_config_file Success\n");

  //Parsing succesfully done.
	return 1;

// //Create container for configuration file content
 // config_t cfg_file_content;

 // //Initialize libconfig parser.
 // config_init(&cfg_file_content);

 // //Parse the file into the configuration container
 // int x = config_read_file(&cfg_file_content, filename);

 // //Check for errors during parsing.
 // if(!x)
 // {
 //   _DISPLAYERROR_("During parsing configuration file, error on line %d: %s\n", 
 //     cfg_file_content.error_line, cfg_file_content.error_text);
 //   return 0;
 // }

 // //Start parsing the configuration.

 // //Parse DISPLAY.size
 // config_setting_t *screen_size = NULL;
 // screen_size = config_lookup(&cfg_file_content, "DISPLAY.size");
 // if (screen_size)
 // {
 //   configuration->res_width = config_setting_get_int_elem(screen_size, 0);
 //   configuration->res_height = config_setting_get_int_elem(screen_size, 1);
 // }

 // //Parse DISPLAY.CORNERS
 // configuration->d0[0] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.topleft.x");
 // configuration->d0[1] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.topleft.y");
 // configuration->d0[2] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.topleft.z");
 // configuration->d1[0] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.topright.x");
 // configuration->d1[1] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.topright.y");
 // configuration->d1[2] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.topright.z");
 // configuration->d2[0] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.bottomright.x");
 // configuration->d2[1] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.bottomright.y");
 // configuration->d2[2] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.bottomright.z");
 // configuration->d3[0] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.bottomleft.x");
 // configuration->d3[1] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.bottomleft.y");
 // configuration->d3[2] = config_lookup_float(&cfg_file_content, "DISPLAY.CORNERS.bottomleft.z");

 // //Parse DISPLAY.offset
 // config_setting_t *offset_array = NULL;
 // offset_array = config_lookup(&cfg_file_content, "DISPLAY.offset");
 // int i;
 // if(offset_array)
 // {
 //   for(i = 0; i < config_setting_length(offset_array); i++)
 //   {
 //     int val = config_setting_get_int_elem(offset_array, i);
 //     configuration->offsets[i]=val;
 //   }
 // }

 // config_destroy(&cfg_file_content);

 // memcpy(cfg,configuration,sizeof(t_standard_display));

 // //Parsing succesfully done.
	//return 1;
}

