#ifndef STANDARDDISPLAY_ERROR_H_
#define STANDARDDISPLAY_ERROR_H_

extern FILE *display_debug;
extern FILE *display_error;

extern int displayerror;
extern int displaydebug;

void _DISPLAYERROR_(const char *format, ...)
#if defined(__GNUC__)
    __attribute__((format(printf,1,2)))
#endif
;

void _DISPLAYDEBUG_(const char *format, ...)
#if defined(__GNUC__)
    __attribute__((format(printf,1,2)))
#endif
;

#endif /*STANDARDDISPLAY_ERROR_H_*/


