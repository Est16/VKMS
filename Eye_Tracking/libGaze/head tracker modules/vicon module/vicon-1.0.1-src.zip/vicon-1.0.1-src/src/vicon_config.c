/****************************************************************************
* 	libGaze
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems
*
*	Copyright(C) 2008
*	Max Planck Institute for Biological Cybernetics Tuebingen
*	BWFIT
*
*	All rights reserved.
*
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.
*
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <parse_conf.h>

#include "vicon_types.h"


t_vicon_config *parse_config_file(char *filename){

	_DEBUG_("configure \n");
	t_vicon_config *cfg;
	cfg = (t_vicon_config*)calloc(1,sizeof(t_vicon_config));

	//pcnf_drop_flags(PCNF_FLAG_DEBUG_OUTPUT_VARNAMES);
	_DEBUG_("openfile: %s\n",filename);
	pcnf_t *pcnf = pcnf_alloc();
	pcnf_read(pcnf,filename);

	_DEBUG_("host\n");
	char* stmp = pcnf_sget(pcnf,"VICON","hostName");
	cfg->host = (char*)malloc((strlen(stmp)+1)*sizeof(char));
	strcpy(cfg->host ,stmp);

	_DEBUG_("cfg->host: %s \n",cfg->host);

	stmp = pcnf_sget(pcnf,"VICON","protocol");
	cfg->protocol = (char*)malloc((strlen(stmp)+1)*sizeof(char));
	strcpy(cfg->protocol,stmp);
	cfg->port = pcnf_iget(pcnf,"VICON","port");
	_DEBUG_("protocol: %s\tport: %d\n",cfg->protocol,cfg->port);
//	t_body_channel *bc;
//	bc = _alloc_t_body_channel();
	cfg->num = pcnf_iget(pcnf,"TRACKED_OBJECTS","num");
	_DEBUG_("num: %d\n",cfg->num);
	cfg->ihead = pcnf_iget(pcnf,"TRACKED_OBJECTS","head");
	_DEBUG_("ihead: %d\n",cfg->ihead);
	cfg->ieye = pcnf_iget(pcnf,"TRACKED_OBJECTS","eye");
	_DEBUG_("ieye: %d\n",cfg->ieye);
	cfg->frequency = pcnf_iget(pcnf,"TRACKED_OBJECTS","frequency");
	_DEBUG_("frequency: %d\n",cfg->frequency);

	cfg->tracked_bodies = (t_body_channel*)malloc(cfg->num*sizeof(t_body_channel));

	int i =0;
	for (i=0;i<cfg->num;i++){
		char trackedobject[128];
		sprintf(trackedobject,"TRACKED_OBJECT%d",i);
		char *stmp;
		stmp = pcnf_sget(pcnf,trackedobject,"name");
		cfg->tracked_bodies[i].name = (char*)malloc((strlen(stmp)+1)*sizeof(char));
		strcpy(cfg->tracked_bodies[i].name,stmp);
		_DEBUG_("s: %s\n",cfg->tracked_bodies[i].name);
		_DEBUG_("cfg->tracked_bodies[%d].name: %s\n",i,cfg->tracked_bodies[i].name);
	}

	pcnf_free(pcnf);
	return cfg;


}

