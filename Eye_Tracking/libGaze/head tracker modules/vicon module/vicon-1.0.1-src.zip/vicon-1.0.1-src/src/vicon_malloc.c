/****************************************************************************
* 	libGaze                                                       
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems   
*                                                               
*	Copyright(C) 2008 	
*	Max Planck Institute for Biological Cybernetics Tuebingen           
*	BWFIT     
*                                                             
*	All rights reserved.                                           
*                                                                   
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.                                                       
*                                                                           
****************************************************************************/
#include "vicon_types.h"
#include <stdlib.h>
t_vicon_config* _alloc_t_vicon_config(void){
	return (t_vicon_config*)malloc(sizeof(t_vicon_config));
}

void _free_t_vicon_config(t_vicon_config* cfg){
	if(cfg!=NULL){
		free(cfg->host);
		free(cfg->protocol);
		
/*
 * TODO
 * 
 */
//		free(cfg->tracked_body);
		free(cfg);
	}
}
/*
t_line* _alloc_t_line(int size){
		t_line* l;
		l =(t_line*)malloc(sizeof(t_line));
		l->s = gsl_vector_alloc(size);
		l->d = gsl_vector_alloc(size);
	
		return l;
}

void _free_t_line(t_line* l){
	if(l!=NULL){
		gsl_vector_free(l->s);
		gsl_vector_free(l->d);
		free(l);
	}
}

t_space* _alloc_t_space(int size){
		t_space* s;
		s =(t_space*)malloc(sizeof(t_space));
		s->s = gsl_vector_alloc(size);
		s->d1 = gsl_vector_alloc(size);
		s->d2 = gsl_vector_alloc(size);
		
		return s;
}

void _free_t_space(t_space* s){
	if(s!=NULL){
		gsl_vector_free(s->s);
		gsl_vector_free(s->d1);
		gsl_vector_free(s->d2);
		free(s);
	}
}
*/
t_general_information_channel *_alloc_t_general_information_channel(void){
	return (t_general_information_channel*)malloc(sizeof(t_general_information_channel));
}
void _free_t_general_information_channel(t_general_information_channel* gic){
	free(gic);
}


t_marker_channel *_alloc_t_marker_channel(void){
	return (t_marker_channel*)malloc(sizeof(t_marker_channel));
}
void _free_t_marker_channel(t_marker_channel* mc){
	free(mc);
}


t_body_channel *_alloc_t_body_channel(void){
	return(t_body_channel*)malloc(sizeof(t_marker_channel));
}
void _free_t_body_channel(t_body_channel* bc){
	if(bc !=NULL){
		free(bc->name);
		free(bc);
	}
}

