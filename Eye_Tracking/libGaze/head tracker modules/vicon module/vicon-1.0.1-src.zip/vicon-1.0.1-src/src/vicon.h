/****************************************************************************
* 	libGaze
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems
*
*	Copyright(C) 2008
*	Max Planck Institute for Biological Cybernetics Tuebingen
*	BWFIT
*
*	All rights reserved.
*
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.
*
****************************************************************************/
#ifndef VICON_H_
#define VICON_H_

#include "vicon_types.h"
#include "vicon_error.h"
#include <libGaze/interfaces/libGaze_head_tracker_module.h>

enum EType{
	ERequest,
	EReply
};

enum EPacket{
	ECLose,
	EInfo,
	EData,
	EStreamOn,
	EStreamOff
};

extern int vicon_is_connected;

extern int m_frame_Channel;

extern  int m_bufferSize;


extern char * m_Buff;
extern char *m_pBuff;

extern char **m_info;

extern long int m_packet;
extern long int m_type;
extern long int m_size;




extern short int m_bPrintBodyNames;
extern short int m_bDebugOutput;

typedef struct{
	int id;
	char *name;
}t_body;


typedef int VICON_SOCKET;


VICON_SOCKET getViconConnection(t_vicon_config*);

void parseObjects(t_body_channel*);

int getBodyData(int,t_body_channel*, t_raw_head_data*);

int init_Vicon(void);

int recieve(int socket, char * pBuffer, int BufferSize);

enum headtracker_return is_head_tracker_connected(void);


#endif /*VICON_H_*/
