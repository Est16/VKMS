/****************************************************************************
* 	libGaze
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems
*
*	Copyright(C) 2008
*	Max Planck Institute for Biological Cybernetics Tuebingen
*	BWFIT
*
*	All rights reserved.
*
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.
*
****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>


#if defined __WIN32__ || defined WIN32
#  include <winsock2.h>
#  include <WS2tcpip.h>
//#  include <cstdio>
#  define socklen_t int
#  define SHUT_RDWR SD_BOTH
//  Windows-specific initialisation.
#define INIT_SOCKET(){\
	WSADATA wsaData; \
	if(WSAStartup( 0x0101, &wsaData ) != 0) \
	{\
		_ERROR_("Socket Initialization Error\n");	\
		return INVALID_SOCKET;	\
	} \
}
#else
//#  include <unistd.h>
#include <errno.h>
#  include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#define NOT_CONNECTED_SOCKET -1
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define INIT_SOCKET()
#endif
/*
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

*/
//#include <errno.h>
//#include <pthread.h>

//#include<glib/gthread.h>

#include <sys/time.h>

#include <libGaze/headtracker/libGaze_headtracker_types.h>
#include "vicon.h"
//#include "vicon_tools.h"
/*
#include <gsl/gsl_blas.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>
*/
#define NOT_CONNECTED_SOCKET -1
//#define INVALID_SOCKET -1
//#define SOCKET_ERROR -1

#define EPSILON 0.000001

int vicon_is_connected = 0;

int m_frame_Channel = 0;

int m_bufferSize = 2040;

char *m_buff = NULL;
char *m_pBuff = NULL;
char **m_info = NULL;

long int m_packet = 0;
long int m_type = 0;
long int m_size = 0;

short int m_bPrintBodyNames = 0;
short int m_bDebugOutput = 0;

long last_sample_time = 0;

t_vicon_config *cfg = NULL;
//t_display *ptr_dis;


VICON_SOCKET vicon_socket = 0;

enum headtracker_return init_head_tracker_module(int idebug, int ierror, FILE *fdebug, FILE *ferror){
	//printf("test\n");
	//if(!g_thread_supported()) g_thread_init(NULL);
	vdebug=idebug;
	verror=ierror;

	//vicon_debug = fdebug;
	//vicon_error = ferror;
	vicon_debug = stdout;
	vicon_error = stderr;

	vicon_socket = NOT_CONNECTED_SOCKET;
	vicon_is_connected = 0;

	//printf("\nINIT\n");
	//_DEBUG_("basetime: %lu\n",log_base_time);
	_DEBUG_("init_module\n");

	m_buff = (char*)malloc(m_bufferSize*sizeof(char));
	return LG_HEADTRACKER_OK;

}

enum headtracker_return fini_head_tracker_module(void){
	_free_t_vicon_config(cfg);
	return LG_HEADTRACKER_OK;
}

enum headtracker_return connect_to_head_tracker(void){


	vicon_socket = getViconConnection(cfg);
	_DEBUG_("soket:%d\n",vicon_socket);
	if(vicon_socket==INVALID_SOCKET){
		vicon_is_connected= 0;
		return LG_HEADTRACKER_COULD_NOT_CONNECT;
	}else{
		int i;
		/*
		 * reads out all channel information for each tracked
		 * object.
		 */

		for (i=0;i<cfg->num;i++){
			parseObjects(&(cfg->tracked_bodies[i]));
		}

		vicon_is_connected= 1;
		return LG_HEADTRACKER_OK;
	}
}

enum headtracker_return disconnect_head_tracker(void){
	int i =0;
	//i = close(vicon_socket);
	vicon_is_connected = 0;
	return LG_HEADTRACKER_OK;
}

enum headtracker_return configure_head_tracker(char *filename, int *ihead, int *ieye,int* num){
	_DEBUG_("configure_head_tracker\n");
	_DEBUG_("cfg: %p\n",cfg);
	cfg = (t_vicon_config*)parse_config_file(filename);
	_DEBUG_("cfg: %p\n",cfg);
	if (cfg==NULL){
		_ERROR_("configure_head_tracker: could not parse file\n");
		return LG_HEADTRACKER_ERROR;
	}
	*ihead = cfg->ihead;
	*ieye = cfg->ieye;
	*num = cfg->num;

	//printf("ihead: %d\tieye: %d\n",*ihead,*ieye);
	return LG_HEADTRACKER_OK;
}

enum headtracker_return start_head_tracking(){
	/*
	g_mutex_lock( mutex_track_state);
	track_state = TRACKING_ENABLED;
	g_mutex_unlock( mutex_track_state);
	free(vicon_tracking_data);
	vicon_tracking_data = (t_head_data*)malloc(cfg->num*sizeof(t_head_data));
	//vicon_log_thread =g_thread_create((GThreadFunc)logging_main,(gpointer)cfg,1,(GError**)&thread_error);
	*/
	return LG_HEADTRACKER_OK;
}


enum headtracker_return stop_head_tracking(void){
	//printf("vicon_stop\n");
	/*
	g_mutex_lock( mutex_track_state);
	track_state = TRACKING_DISABLED;
	g_mutex_unlock( mutex_track_state);
	g_thread_join(vicon_log_thread);
	*/
	return LG_HEADTRACKER_OK;
}

enum headtracker_return get_head_tracking_data( t_raw_head_data* hd){

	_DEBUG_("get_tracking_data\n");
	enum headtracker_return ireturn;
	ireturn = getBodyData(cfg->num,cfg->tracked_bodies,hd);

	return ireturn;


}

VICON_SOCKET getViconConnection(t_vicon_config *cfg){

	_DEBUG_("getViconConnection\n");

	INIT_SOCKET()
	_DEBUG_("cfg: %p\n",cfg);
	if(cfg == NULL){
		return INVALID_SOCKET;
	}

	int type;
	int socketfd; /*filediscriptor of the socket*/

	struct protoent *pEntry;
	type = SOCK_STREAM;

	_DEBUG_("petProto: %s\n",cfg->protocol);
	//pEntry = getprotobyname(cfg->protocol);
	pEntry = getprotobyname("tcp");
//	assert(pEntry);
	_DEBUG_("socket()\n");
	socketfd = socket(PF_INET,type,pEntry->p_proto);

	if(socketfd == INVALID_SOCKET){

		_ERROR_("INVALID_SOCKET\n");
		return INVALID_SOCKET;
	}

	struct sockaddr_in Endpoint;
	struct hostent* pHostInfo = NULL;

	memset(&Endpoint, 0, sizeof(Endpoint));

	Endpoint.sin_family = AF_INET;

	/*BigEndian littleEndian ???*/
	Endpoint.sin_port = htons(cfg->port);
	pHostInfo = gethostbyname(cfg->host);
	if(pHostInfo == NULL){
		_ERROR_("gethostbyname: %s\n",cfg->host);
		return -1;
	}else{
		_DEBUG_("h_name: %s\n",pHostInfo->h_name);
		_DEBUG_("h_length: %d\n",pHostInfo->h_length);
		_DEBUG_("h_addrtype: %d\n",pHostInfo->h_addrtype);
		_DEBUG_("h_addr: %s\n",pHostInfo->h_addr_list[0]);
	}

	Endpoint.sin_addr = *((struct in_addr*)pHostInfo->h_addr);

//	Endpoint.sin_addr.s_addr = inet_addr(host);

	int result = connect(socketfd, (struct sockaddr*) &Endpoint, sizeof(Endpoint));
	if(result == -1){
		_ERROR_("could not connect to server\n");
		_ERROR_("errno: %d\n",errno);

		return -1;
	}
	return socketfd;
}



int recieve(int socket, char * pBuffer, int BufferSize)
{

  char * p = pBuffer;
	char * e = pBuffer + BufferSize;

	int result;

	while(p != e)
	{
		result = recv(	socket, p, e - p, 0 );

		if(result == SOCKET_ERROR)
			return 0;

		p += result;
	}

	return 1;
}

void parseObjects(t_body_channel *body){

	int i;

	m_pBuff = m_buff;
	*((long int *)m_pBuff) = EInfo;
	m_pBuff+=sizeof(long int);
	*((long int *) m_pBuff) = ERequest;
	m_pBuff+=sizeof(long int);

	if(send(vicon_socket, m_buff, m_pBuff - m_buff, 0) == SOCKET_ERROR)
		_ERROR_("Error Requesting\n");

	if(!recieve(vicon_socket, (char*) &m_packet, sizeof(m_packet)))
		_ERROR_("Error Recieving\n");

	if(!recieve(vicon_socket, (char*) &m_type,sizeof(m_type)))
		_ERROR_("Error Recieving\n");

	if(m_type != EReply)
		_ERROR_("Bad Packet\n");

	if(m_packet != EInfo)
		_ERROR_("Bad Reply Type(data)\n");

	if(!recieve(vicon_socket, (char*) &m_size,sizeof(m_size)))
		_ERROR_("ERROR recieve m_size\n");


	m_info = (char **)malloc(m_size*sizeof(char*));

	for(i=0;i<m_size;i++){
		long int s;
		char *p;


		if(!recieve(vicon_socket, (char *) &s, sizeof(long int)))
			_ERROR_("ERROR getting info size\n");

		m_info[i] = (char*)malloc((s+1)*sizeof(char));
		p = m_info[i];
		if(!recieve(vicon_socket, p,s))
			_ERROR_("ERROR getting info\ti: %d\ts: %li\n",i,s);

	}

	for(i = 0; i<m_size;i++){
		char s[255];
		char *name = s;
//		_DEBUG_("INFO %d\t%s\n",i,m_info[i]);
		char *ms = m_info[i];
		//find info-type "<"...">"
		int openBrace = strcspn(m_info[i],"<");
		int closeBrace = strcspn(m_info[i],">");

		int len = closeBrace -openBrace -1;

//		_DEBUG_("openBrace: %d\tcloseBrace: %d\n",openBrace,closeBrace);
//		_DEBUG_("info length: %d\n",strlen(ms));
		strncpy(name,&ms[openBrace+1],len);
		name[len] = '\0';
//		_DEBUG_("name: %s\n",name);
//		_DEBUG_("body->name: %p\n",body->name);
		if(!strcmp(name,"F")){
			m_frame_Channel = i;
		}else if(!strcmp(name,"A-X")){
//			_DEBUG_("A-X\n");
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s A-X: %d\n",body->name,i);
				body->rx =i;
			}
		}else if(!strcmp(name,"A-Y")){
//			_DEBUG_("A-Y\n");
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s A-Y: %d\n",body->name,i);
				body->ry =i;
			}
		}else if(!strcmp(name,"A-Z")){
//			_DEBUG_("A-Z\n");
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s A-Z: %d\n",body->name,i);
				body->rz =i;
			}
		}else if(!strcmp(name,"T-X")){
//			_DEBUG_("T-X\n");
//			_DEBUG_("ms: %s\n",ms);
//			_DEBUG_("body->name: %s\n",body->name);
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s T-X: %d\n",body->name,i);
				body->tx =i;
			}
		}else if(!strcmp(name,"T-Y")){
//			_DEBUG_("T-Y\n");
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s T-Y: %d\n",body->name,i);
				body->ty =i;
			}
		}else if(!strcmp(name,"T-Z")){
//			_DEBUG_("T-Z\n");
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s T-Z: %d\n",body->name,i);
				body->tz =i;
			}
		}else if(!strcmp(name,"ba-X")){
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s ba-X: %d\n",body->name,i);
				body->bx =i;
			}
		}else if(!strcmp(name,"ba-Y")){
			if(!strncmp(ms,body->name,strlen(body->name))){
				_DEBUG_("%s ba-Y: %d\n",body->name,i);
				body->by =i;
			}
		}else if(!strcmp(name,"ba-Z")){
			if(!strncmp(ms,body->name,strlen(body->name))){
			_DEBUG_("%s ba-Z: %d\n",body->name,i);
				body->bz =i;
			}
		}else{

		}

	}


}


int getBodyData(int n,t_body_channel *bodies, t_raw_head_data *bodydata){

	int i;
	//double timestamp;

	m_pBuff = m_buff;

	*((long int*) m_pBuff) = EData;
	m_pBuff += sizeof(long int);
	*((long int*) m_pBuff) = ERequest;
	m_pBuff += sizeof(long int);

	if(send(vicon_socket, m_buff, m_pBuff - m_buff, 0) == SOCKET_ERROR)
			_ERROR_("Error Requesting, probably vicon host not found.");


	//	Get and check the packet header.
	if(!recieve(vicon_socket, (char *) &m_packet, sizeof(m_packet)))
		_ERROR_("Error Recieving\n");

	if(!recieve(vicon_socket, (char *) &m_type, sizeof(m_type)))
		_ERROR_("Error Recieving\n");

	if(m_type != EReply)
		_ERROR_("Bad Packet (getData)\n");

	if(m_packet != EData)
		_ERROR_("Bad Reply Type (getData)\n");

	if(!recieve(vicon_socket, (char *) &m_size, sizeof(m_size)))
		_ERROR_("\n");
/*
	if(m_size != m_info.size())
		_ERROR_("Bad Data Packet\n");
	*/

	double data[m_size];
	for (i=0;i<m_size;i++){
		if(!recieve(vicon_socket, (char*) &(data[i]), sizeof(double)))
			_ERROR_("ERROR could not recieve data no: %d\n",i);
			//return LG_HEADTRACKER_ERROR;
	}

/*
	for (i=0;i<m_size;i++){
		_DEBUG_("Data %d: %f\n",i,data[i]);
	}
*/
//	gsl_matrix *m =gsl_matrix_calloc(3,3);

//	matrix_rotationXYZ(m,'x',radians(90.0));

	//printf("m_frame_Channel: %f\n",data[m_frame_Channel]);

	if(last_sample_time < data[m_frame_Channel]){

		for (i=0;i<n;i++){
			//_DEBUG_("i: %d\n",i);
			//getting the body coordinates (position) out of the vicon-dataset
/*test if it can be deleted
			gsl_vector* v = gsl_vector_calloc(3);
			bodydata[i].time = data[m_frame_Channel];

			bodydata[i].position[0] = data[bodies[i].tx];
			bodydata[i].position[1]  = data[bodies[i].ty];
			bodydata[i].position[2]  = data[bodies[i].tz];

			gsl_vector_view vw = gsl_vector_view_array(bodydata[i].position,3);
			gsl_blas_dgemv(CblasNoTrans,1.0,m,&vw.vector,1.0,v);
			//printf("position: %f\t%f\t%f\tv: %f\t%f\t%f\n",bodydata[i].position[0],bodydata[i].position[1],bodydata[i].position[2],gsl_vector_get(v,0),gsl_vector_get(v,1),gsl_vector_get(v,2));
			bodydata[i].position[0] = gsl_vector_get(v,0);
			bodydata[i].position[1] = gsl_vector_get(v,1);
			bodydata[i].position[2] = gsl_vector_get(v,2);
*/
			bodydata[i].position[0] = data[bodies[i].tx];
			bodydata[i].position[1]  = data[bodies[i].tz];
			bodydata[i].position[2]  = -data[bodies[i].ty];

			//VELIB-STUFF
			//The channel data is in the angle-axis form.
			//	The following converts this to a quaternion.
			//=============================================================
			//	An angle-axis is vector, the direction of which is the axis
			//	of rotation and the length of which is the amount of
			//	rotation in radians.
			//=============================================================


			double qw,qx,qy,qz;

			double len;
			len = sqrt(data[bodies[i].rx] * data[bodies[i].rx] + data[bodies[i].ry] * data[bodies[i].ry] +data[bodies[i].rz]*data[bodies[i].rz]);

			qw= cos(len/2.0);
			double tmp = sin(len/2.0);
			//	The following converts angle-axis to a rotation matrix.
			double c, s, x, y, z;

			if (len < 1e-15)
			{
				qx= data[bodies[i].rx];
				qy= data[bodies[i].ry];
				qz= data[bodies[i].rz];

				bodydata[i].matrix[0] = bodydata[i].matrix[4] = bodydata[i].matrix[8] = 1.0;
				bodydata[i].matrix[1] = bodydata[i].matrix[2] = bodydata[i].matrix[3] =
				bodydata[i].matrix[5] = bodydata[i].matrix[6] = bodydata[i].matrix[7] = 0.0;
			}
			else
			{
				/*
				//original way to calculate quaternions
				qx= data[bodies[i].rx]/len*tmp;
				qy= data[bodies[i].ry]/len*tmp;
				qz= data[bodies[i].rz]/len*tmp;
				*/
				//correct vicon to righthanded coordinate system
				qx= data[bodies[i].rx]/len*tmp;
				qz= -(data[bodies[i].ry]/len*tmp);
				qy= data[bodies[i].rz]/len*tmp;

				/*
				//original rotation axis
				x = data[bodies[i].rx]/len;
			  	y = data[bodies[i].ry]/len;
				z = data[bodies[i].rz]/len;
				 */
				//correct viconrotation axis to righthanded coordinate system
				/*
				x = data[bodies[i].rx]/len;
			  	y = data[bodies[i].rz]/len;
				z = -data[bodies[i].ry]/len;

			  	c = cos(len);
				s = sin(len);

				//axis and angle to rotation matrix
				//see http://en.wikipedia.org/wiki/Rotation_matrix#Axis_and_angle

				bodydata[i].matrix[0] = c + (1-c)*x*x;
				bodydata[i].matrix[1] = (1-c)*x*y + s*(-z);
				bodydata[i].matrix[2] = (1-c)*x*z + s*y;
				bodydata[i].matrix[3] = (1-c)*y*x + s*z;
				bodydata[i].matrix[4] = c + (1-c)*y*y;
				bodydata[i].matrix[5] = (1-c)*y*z + s*(-x);
				bodydata[i].matrix[6] = (1-c)*z*x + s*(-y);
				bodydata[i].matrix[7] = (1-c)*z*y + s*x;
				bodydata[i].matrix[8] = c + (1-c)*z*z;

				*/
				//Convert from quaternion
				// see http://en.wikipedia.org/wiki/Rotation_matrix#Quaternion
				bodydata[i].matrix[0] = 1-2*(qy*qy)-2*(qz*qz);
				bodydata[i].matrix[1] = 2*qx*qy-2*qz*qw;
				bodydata[i].matrix[2] = 2*qx*qz+2*qy*qw;
				bodydata[i].matrix[3] = 2*qx*qy+2*qz*qw;
				bodydata[i].matrix[4] = 1-2*qx*qx-2*qz*qz;
				bodydata[i].matrix[5] = 2*qy*qz-2*qx*qw;
				bodydata[i].matrix[6] = 2*qx*qz-2*qy*qw;
				bodydata[i].matrix[7] = 2*qy*qz+2*qx*qw;
				bodydata[i].matrix[8] = 1-2*qx*qx-2*qy*qy;
			}

			// now convert rotation matrix to nasty Euler angles (yuk)
			// you could convert direct from angle-axis to Euler if you wish

			//	'Look out for angle-flips, Paul...'
			//  Algorithm: GraphicsGems II - Matrix Techniques VII.1 p 320
			//	assert(fabs(bodydata[i].matrix[0][2]) <= 1);
			/*

			double eulerx, eulery, eulerz;

			eulery = asin(-bodydata[i].matrix[6]);

			if(fabs(cos(y)) > EPSILON ) 	// cos(y) != 0 Gimbal-Lock
			{
				eulerx = atan2(bodydata[i].matrix[7], bodydata[i].matrix[8]);
				eulerz = atan2(bodydata[i].matrix[3], bodydata[i].matrix[0]);
			}
			else
			{
				eulerx = 0;
				eulerz = atan2(bodydata[i].matrix[1], bodydata[i].matrix[4]);
			}

			eulerx = (eulerx/M_PI)*180.0;
			eulery = (eulery/M_PI)*180.0;
			eulerz = (eulerz/M_PI)*180.0;
			*/


			//roll pitch yaw
			//see http://de.wikipedia.org/wiki/Roll-Pitch-Yaw-Winkel
			//heading = Y-axis bank=X-axis attitude = Z-axis
/*
			double beta, alpha,gamma;
			beta = atan2(-bodydata[i].matrix[6],sqrt(pow(bodydata[i].matrix[0],2)+pow(bodydata[i].matrix[3],2)));
			alpha = atan2(bodydata[i].matrix[3]/cos(beta),bodydata[i].matrix[0]/cos(beta));
			gamma = atan2(bodydata[i].matrix[7]/cos(beta),bodydata[i].matrix[8]/cos(beta));
*/
			//printf("alpha: %f\tbeta: %f\tgamma: %f\n",(alpha/M_PI)*180.0,(beta/M_PI)*180.0,(gamma/M_PI)*180.0);
/*
			double heading, attitude,bank;
			heading = atan2(2*qy*qw-2*qx*qz,1-2*qy*qy-2*qz*qz);
			attitude = asin(2*qx*qy+2*qz*qw);
			bank = atan2(2*qx*qw-2*qy*qz,1-2*qx*qx-2*qz*qz);
*/
			//printf("heading: %f\tattitude: %f\tbank: %f\n",(heading/M_PI)*180.0,(attitude/M_PI)*180.0,(bank/M_PI)*180.0);
/*

			double trace = bodydata[i].matrix[0]+bodydata[i].matrix[4]+bodydata[i].matrix[8]+1.0;
			if(trace> 0.00000001){
				double s= 0.5 / sqrt(trace);
				qw = 0.25 /s;
				qx = (bodydata[i].matrix[7]-bodydata[i].matrix[5])*s;
				qy = (bodydata[i].matrix[2]-bodydata[i].matrix[6])*s;
				qz = (bodydata[i].matrix[3]-bodydata[i].matrix[1])*s;
			}else{
				if(bodydata[i].matrix[0]>bodydata[i].matrix[4]&&bodydata[i].matrix[0]>bodydata[i].matrix[8]){
					double s= 2.0*sqrt(1.0 +bodydata[i].matrix[0]-bodydata[i].matrix[4]-bodydata[i].matrix[8]);
					qw = (bodydata[i].matrix[5]-bodydata[i].matrix[7])*s;
					qx = 0.25 *s;
					qy = (bodydata[i].matrix[1]+bodydata[i].matrix[3])*s;
					qz = (bodydata[i].matrix[2]+bodydata[i].matrix[6])*s;
				}else if(bodydata[i].matrix[4]>bodydata[i].matrix[8]){
					double s= 2.0*sqrt(1.0 +bodydata[i].matrix[4]-bodydata[i].matrix[0]-bodydata[i].matrix[8]);
					qw = (bodydata[i].matrix[2]-bodydata[i].matrix[6])*s;
					qx = (bodydata[i].matrix[1]+bodydata[i].matrix[3])*s;
					qy = 0.25 *s;
					qz = (bodydata[i].matrix[5]+bodydata[i].matrix[7])*s;
				}else{
					double s= 2.0*sqrt(1.0 +bodydata[i].matrix[8]-bodydata[i].matrix[0]-bodydata[i].matrix[4]);
					qw = (bodydata[i].matrix[1]-bodydata[i].matrix[3])*s;
					qx = (bodydata[i].matrix[2]+bodydata[i].matrix[6])*s;
					qy = (bodydata[i].matrix[5]+bodydata[i].matrix[7])*s;
					qz = 0.25 *s;
				}
			}

			double heading2, attitude2,bank2;
			heading2 = atan2(2*qy*qw-2*qx*qz,1-2*qy*qy-2*qz*qz);
			attitude2 = asin(2*qx*qy+2*qz*qw);
			bank2 = atan2(2*qx*qw-2*qy*qz,1-2*qx*qx-2*qz*qz);

			//printf("heading2: %f\tattitude2: %f\tbank2: %f\n",(heading2/M_PI)*180.0,(attitude2/M_PI)*180.0,(bank2/M_PI)*180.0);
*/
		}

		last_sample_time = data[m_frame_Channel];
		return LG_HEADTRACKER_NEW_DATA;
	}else{
		return LG_HEADTRACKER_NO_NEW_DATA_AVAILABLE;
	}
}


enum headtracker_return is_head_tracker_connected(void){
	if(vicon_is_connected == 1){
		return LG_HEADTRACKER_IS_CONNECTED;
	}
	return LG_HEADTRACKER_NOT_CONNECTED;
}


enum headtracker_return get_tracker_frequency(int* frequency){
	*frequency = cfg->frequency;
	return LG_HEADTRACKER_OK;

}
