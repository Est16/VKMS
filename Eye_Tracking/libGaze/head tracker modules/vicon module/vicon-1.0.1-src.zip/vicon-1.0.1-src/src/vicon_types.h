/****************************************************************************
* 	libGaze
*  A framework to combine off-the-shelf video-based eye tracking systems
*	with motion caputing systems
*
*	Copyright(C) 2008
*	Max Planck Institute for Biological Cybernetics Tuebingen
*	BWFIT
*
*	All rights reserved.
*
*	This file is part of libGaze.
*
*	libGaze is free software: you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  libGaze is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with libGaze.  If not, see <http://www.gnu.org/licenses/>.
*
****************************************************************************/
#ifndef VICON_TYPES_H_
#define VICON_TYPES_H_

/*
 * BEWARE COORDINATE SYSTEM OF VICON IS
 *
 *
 * 				| (Z)
 * 				|
 * 				|
 * 				|    / (Y)
 * 				|  /
 * 				|/______________(X)
 * (Y AND Z ARE SWITCHED)
 * */


typedef struct{

	int timestamp;
	int framerate;

}t_general_information_channel;

t_general_information_channel *_alloc_t_general_information_channel(void);
void _free_t_general_information_channel(t_general_information_channel*);

typedef struct{
		char *name;
		/*The int values give the position of the value inside the data-block*/
		int x;
		int y;
		int z;
		int o;

}t_marker_channel;

t_marker_channel *_alloc_t_marker_channel(void);
void _free_t_marker_channel(t_marker_channel*);

typedef struct{
	double x;
	double y;
	double z;
	int visible;
}t_marker_data;


typedef struct{
	char *name;
	/*The int values give the position of the value inside the data-block*/
	int tx;
	int ty;
	int tz;
	int rx;
	int ry;
	int rz;

	//basis global-orientation
	int bx;
	int by;
	int bz;

}t_body_channel;

t_body_channel *_alloc_t_body_channel(void);
void _free_t_body_channel(t_body_channel*);

typedef struct{

	long time;

	//Representation of the global body-orientation
	double bx;
	double by;
	double bz;


	//RepresentATION OF BODY TRANSLATION
	double tx;
	double ty;
	double tz;

	//Representaion of body rotation
	//Quaternion
	double qx;
	double qy;
	double qz;

	//Global rotation matrix
	double globalRotation[3][3];

	double eulerx;
	double eulery;
	double eulerz;
}t_body_data;


typedef struct{
	char *host;	//the host-name of the Vicon Server
	int port;	//the port for the socket connection
	char *protocol;
	int num;	//number of objects which are tracked
	int ihead;
	int ieye;
	int frequency;
	t_body_channel *tracked_bodies;

}t_vicon_config;

t_vicon_config* _alloc_t_vicon_config(void);
void _free_t_vicon_config(t_vicon_config*);
#endif /*VICON_TYPES_H_*/
